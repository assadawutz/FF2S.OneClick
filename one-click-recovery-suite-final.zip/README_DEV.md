# One-Click Recovery Toolkit
Use:
- ./dev-orchestrator.sh --deep
- ./dev-orchestrator.sh --build-all --parallel
- ./dev-orchestrator.sh --run-all
- ./dev-orchestrator.sh --report
Advanced sequence:
- ./orchestrator-sequence.sh "ios:1,3" "android:4,6" build-all run-all report
